package com.whatsapp.tests;

import com.whatsapp.config.Helper;
import com.whatsapp.data.Chat;


import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.touch.TouchActions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;


import java.util.Random;

import static org.openqa.selenium.support.ui.ExpectedConditions.presenceOfElementLocated;
import static org.testng.Assert.assertEquals;


/**
 * Created by kdl on 21.12.15.
 */
public class Messaging {
    //    @Test(groups = { "init" })
    public Messaging(AndroidDriver driver, WebDriverWait wait, TouchActions touchScreen) {
        this.wait = wait;
        this.touchScreen = touchScreen;
        this.driver = driver;
//        this.helper = helper;

        PageFactory.initElements(driver, Chat.class); //path to locator class
    }

    private WebDriverWait wait;
    private TouchActions touchScreen;
    private WebDriver driver;


    public void deleteRandomMsgs() {
        for (WebElement msg : Chat.msgItems) {
            if (msg.getText().equalsIgnoreCase(Chat.randomData)) {
                System.out.println("Find message to delete");
                touchScreen.longPress(msg).perform();
                Chat.abDelete.click();
                Chat.popupDeleteBtn.click();
            }
        }
    }



    public void deleteMsgs() {
//    wait.until(presenceOfElementLocated(By.id("list")));
        for (WebElement msg : Chat.msgItems) {
            if (msg.getText().equalsIgnoreCase(Chat.msgTestData)) {
                System.out.println("Message find to delete");
                touchScreen.longPress(msg).perform();
                Chat.abDelete.click();
                Chat.popupDeleteBtn.click();
            } else {
                System.out.println("Message do not find");
            }
        }


//
//    int listMsgs = Chat.msgItems.size();
//    System.out.println(listMsgs);
//    WebElement lastListMsg = Chat.msgItems.get(listMsgs);
//    System.out.println(lastListMsg.getText());
//    assertEquals(Chat.msgTestData, lastListMsg.getText());
//    touchScreen.longPress(lastListMsg);
//    int lastListMsg = msgList;

//    Thread.sleep(3000);
    }

    //@Test(dependsOnGroups = { "init.*" })
    public void whatsAppSwipe() throws InterruptedException {
        wait.until(presenceOfElementLocated(By.id("list")));
        touchScreen.flick(Chat.chatList, -300, 0, 95).perform();
        Thread.sleep(3000);
        touchScreen.flick(Chat.chatList, 300, 0, 95).perform();

//    touchScreen.longPress(chatList).move(200,500).release().perform();
    }

    //@Test(dependsOnGroups = { "init.*" })
    public void openContactChat(int n) {
        wait.until(presenceOfElementLocated(By.id("toolbar")));
        if (Chat.chatItem.isEmpty()) {
            System.out.println("You don't have any chats");
        } else {
            wait.until(presenceOfElementLocated(By.id("list")));
            Chat.chatItem.get(n).click();
        }
    }

    //@Test(dependsOnGroups = { "init.*" })
    public void checkMenuItems() {
        wait.until(presenceOfElementLocated(By.id("toolbar")));

        Chat.menuIcon.click();
        Chat.menuList.get(0).click();
        driver.navigate().back();

        Chat.menuIcon.click();
        Chat.menuList.get(1).click();
        driver.navigate().back();

        Chat.menuIcon.click();
        Chat.menuList.get(2).click();
        driver.navigate().back();

        Chat.menuIcon.click();
        Chat.menuList.get(3).click();
        driver.navigate().back();

        Chat.menuIcon.click();
        Chat.menuList.get(4).click();
        driver.navigate().back();

        Chat.menuIcon.click();
        Chat.menuList.get(5).click();
        driver.navigate().back();
    }

    //@Test(dependsOnGroups = { "init.*" })
    public void createChatGroup() {
        wait.until(presenceOfElementLocated(By.id("list")));
        Chat.menuIcon.click();
        Chat.menuList.get(0).click();
        Chat.groupInput.sendKeys(Chat.msgTestData);
        Chat.submitAction.click();
        Chat.contactNameInput.sendKeys("дмитрий кравченко");
        Chat.chooseContact.click();
        Chat.submitAction.click();
    }

    //@Test(dependsOnGroups = { "init.*" })
    public void openGroupChat() {
        wait.until(presenceOfElementLocated(By.id("toolbar")));

        if (Chat.chatContacts.isEmpty()) {
            System.out.println("You don't have any chats");
        } else {
            wait.until(presenceOfElementLocated(By.id("list")));

            int lastChat = Chat.chatContacts.size() - 1;
            System.out.println(lastChat);
            WebElement lastChatItem = Chat.chatContacts.get(lastChat);
            System.out.println(lastChatItem);
            Helper.checkElementPresence(Chat.chatContacts, Chat.msgTestData);
        }

    }

    public void sendMessage() {
        wait.until(presenceOfElementLocated(By.id("entry")));
        Chat.messageField.sendKeys(Chat.msgTestData);
        Chat.sendButton.click();
    }

    public void sendRandomMessage() {
        wait.until(presenceOfElementLocated(By.id("entry")));
        Chat.messageField.sendKeys(Chat.randomData);
        Chat.sendButton.click();
    }

//
//public void checkLastMsg(){
//
//}

}

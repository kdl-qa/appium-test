package com.whatsapp.data;

import com.whatsapp.config.Helper;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;
import java.util.Random;

/**
 * Created by kdl on 30.12.15.
 */
public class Chat {
    public static String randomData = Helper.generateText(new Random(), Chat.msgTestData, 10);
    public final static String someData = /*"More options";*/ "Другие параметры";
    public final static String msgTestData = "Appium test!!!";
    public final static String msgTestData2 = "Zeus is a Greek god of the lighting";


    @FindBy(id = "toolbar")
    public static WebElement activityBar;

    @FindBy(className = "android.widget.RelativeLayout")
    public static List<WebElement> chatItem;

    @FindBy(id = "conversations_row_contact_name")
    public static List<WebElement> chatContacts;

    @FindBy(id = "list")
    public static WebElement chatList;

    @FindBy(id = "entry")
    public static WebElement messageField;

    @FindBy(id = "send")
    public static WebElement sendButton;

    @FindBy(id = "status")
    public static WebElement msgStatus;

    @FindBy(id = "message_text")
    public static List<WebElement> msgItems;

    @FindBy(id = "menuitem_new_conversation")
    public static WebElement newActiveBarChat;

    @FindBy(className = "android.widget.LinearLayout")
    public static List<WebElement> menuList;

    @FindBy(name = someData)
    public static WebElement menuIcon;

    @FindBy(id = "group_name")
    public static WebElement groupInput;

    @FindBy(id = "action_done")
    public static WebElement submitAction;

    @FindBy(id = "autocomplete_contact_name")
    public static WebElement contactNameInput;

    @FindBy(id = "autocomplete_contact_anchor")
    public static WebElement chooseContact;

    @FindBy(name = msgTestData)
    public static WebElement findGroup;

    @FindBy(id = "menuitem_delete")
    public static WebElement abDelete;

    @FindBy(id = "button1")
    public static WebElement popupDeleteBtn;

    @FindBy(id = "button2")
    public static WebElement popupCancelBtn;

}
